#include "DHT.h"

// DHT22 sensörünün bağlı olduğu dijital pini tanımlıyoruz
#define DHTPIN 4 

// Sensör tipini DHT22 olarak belirliyoruz
#define DHTTYPE DHT22   

// DHT sensör nesnesini oluşturuyoruz
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  // Seri iletişimi 115200 baud hızında başlatıyoruz
  Serial.begin(115200);
  Serial.println(F("DHT22 Testi Başlıyor..."));

  // DHT sensörünü başlatıyoruz
  dht.begin();
}

void loop() {
  // Okumalar arasında 2 saniye bekliyoruz (DHT22 yavaş bir sensördür)
  delay(2000);

  // Nem oranını okuyoruz
  float nem = dht.readHumidity();
  // Sıcaklığı Celsius cinsinden okuyoruz (varsayılan)
  float sicaklik = dht.readTemperature();

  // Okuma hatası olup olmadığını kontrol ediyoruz
  if (isnan(nem) || isnan(sicaklik)) {
    Serial.println(F("DHT sensöründen veri okunamadı!"));
    return;
  }

  // Sonuçları Seri Monitöre yazdırıyoruz
  Serial.print(F("Nem: %"));
  Serial.print(nem);
  Serial.print(F("  |  Sıcaklık: "));
  Serial.print(sicaklik);
  Serial.println(F("°C"));
}
